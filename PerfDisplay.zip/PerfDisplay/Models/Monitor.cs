﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerfDisplay.Models
{
   public class Monitor
    {
        public string CPU { get; set; }
        public string Memory { get; set; }
        public string Disk { get; set; }
    }
}
